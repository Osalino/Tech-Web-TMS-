# Fake Paypal Proof Generator

## What is this?
It generates proof of paypal payment (example: You've sent 2334.21 USD to example@gmail.com)
![proof](https://cdn.discordapp.com/attachments/806324204786024448/810994223959900200/Screenshot_2021-02-15_at_1.59.12_PM.png)
<br> 
## How does it work?
1. Download the code and open index.html (go straight to this website link already ready )
2. Fill in the form

![form](https://media.discordapp.net/attachments/683229791901712391/683401590660399161/paypalgenerator.PNG?width=1241&height=608)

You're done! All simple, easy

## Credits :
By Misspoken - https://github.com/misspoken69 and Misspoken#1122!
